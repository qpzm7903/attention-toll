var content=(function(){function e(e){return e}var t=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome,n={2:15,3:10,4:5},r={2:10,3:20,4:30},i=`我选择用注意力交换娱乐`,a=5e3,o=`
:host { all: initial; }
* { box-sizing: border-box; font-family: -apple-system, "PingFang SC", "Microsoft YaHei", sans-serif; }
.backdrop {
  position: fixed; inset: 0; z-index: 2147483647;
  display: flex; align-items: flex-start; justify-content: center;
  background: rgba(12, 16, 24, .45);
}
.notice {
  margin-top: 10vh; max-width: 480px; width: 92%;
  background: #2c3e50; color: #fff; padding: 24px 28px; border-radius: 14px;
  box-shadow: 0 12px 48px rgba(0,0,0,.45); font-size: 15px; line-height: 1.8;
}
.notice h1 { font-size: 18px; margin: 0 0 10px; color: #fff; }
.notice .bar { height: 8px; border-radius: 4px; background: rgba(255,255,255,.15); overflow: hidden; margin: 12px 0; }
.notice .fill { height: 100%; background: linear-gradient(90deg, #4a90d9, #e6a23c, #d9534f); }
.notice button {
  margin-top: 12px; padding: 8px 18px; border: none; border-radius: 8px;
  background: #e6a23c; color: #fff; cursor: pointer; font-size: 14px;
}
.overlay {
  position: fixed; inset: 0; z-index: 2147483647;
  background: rgba(12, 16, 24, .96); color: #eee;
  display: flex; align-items: center; justify-content: center;
}
.card { max-width: 480px; width: 90%; text-align: center; padding: 24px; }
.card h1 { font-size: 22px; margin: 0 0 12px; color: #fff; }
.card p { font-size: 15px; line-height: 1.8; color: #bbb; margin: 8px 0; }
.card .stat { font-size: 15px; color: #e6a23c; }
.echo {
  font-size: 14px; line-height: 1.7; color: #9fc3ee; background: #16202e;
  border-left: 3px solid #4a90d9; border-radius: 6px; padding: 10px 14px;
  margin: 14px 0; text-align: left;
}
.echo b { color: #fff; }
.countdown { font-size: 44px; font-weight: 700; color: #e6a23c; margin: 18px 0; }
.card textarea, .card input[type=text] {
  width: 100%; padding: 10px 12px; border-radius: 8px; border: 1px solid #445;
  background: #1a2230; color: #fff; font-size: 14px; margin: 12px 0; outline: none;
}
.phrase { font-size: 15px; color: #fff; background: #1a2230; border-radius: 8px; padding: 10px; margin: 12px 0; user-select: none; }
.actions { display: flex; gap: 12px; justify-content: center; margin-top: 16px; }
.btn-continue {
  padding: 10px 22px; border: none; border-radius: 8px; font-size: 14px; cursor: pointer;
  background: #d9534f; color: #fff;
}
.btn-continue:disabled { background: #555; cursor: not-allowed; }
.btn-leave {
  padding: 10px 22px; border: 1px solid #4a90d9; border-radius: 8px; font-size: 14px;
  cursor: pointer; background: transparent; color: #4a90d9;
}
.btn-leave.primary { background: #4a90d9; color: #fff; }
.btn-leave:disabled { border-color: #555; color: #777; background: transparent; cursor: not-allowed; }
.btn-back { border: none; background: none; color: #888; font-size: 13px; cursor: pointer; margin-top: 14px; }
.hint { color: #e6a23c; font-size: 13px; line-height: 1.6; margin-top: 12px; }
`,s=e({matches:[`http://*/*`,`https://*/*`],main(){let e=null,s=null,c=`none`;function l(){if(s)return s;e=document.createElement(`attention-toll-root`),s=e.attachShadow({mode:`closed`});let t=document.createElement(`style`);return t.textContent=o,s.appendChild(t),document.documentElement.appendChild(e),s}function u(){e?.remove(),e=null,s=null,c=`none`}let d=e=>Math.floor(e/60),f=e=>(e/60/25).toFixed(1);async function p(e){try{return await t.runtime.sendMessage(e),!0}catch{return!1}}function m(e){let t=e.querySelector(`.hint`);t||(t=document.createElement(`div`),t.className=`hint`,e.appendChild(t)),t.textContent=`⚠️ 插件已更新，当前页面与它断开了连接——请刷新本页后重试（刚写的内容仍在输入框里，可先复制）。`}let h=e=>e.replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e]);function g(e){if(!e)return``;let t=Math.max(1,Math.round((Date.now()-e.ts)/6e4));return`<div class="echo">你 <b>${t>=60?`${Math.floor(t/60)} 小时 ${t%60} 分钟前`:`${t} 分钟前`}</b>${e.outcome===`left`?`离开时写下`:`继续访问时写下`}：<b>“${h(e.text)}”</b>${e.outcome===`left`?`<br/>现在，你又回来了。`:``}</div>`}async function _(){let e;try{e=await t.runtime.sendMessage({type:`get-state`})}catch{return}if(!e?.tracked){u();return}e.blocked?c!==e.level&&y(e):e.showToast?c!==`toast`&&v(e):u()}function v(e){u(),c=`toast`;let t=l(),n=Math.min(100,e.todaySeconds/60/e.thresholds.l4*100),r=document.createElement(`div`);r.className=`backdrop`,r.innerHTML=`
        <div class="notice">
          <h1>⏳ 注意力关税提醒</h1>
          <div>今日已在分心网站消耗 <b>${d(e.todaySeconds)} 分钟</b>——
          相当于 <b>${f(e.todaySeconds)} 个</b>深度专注块（25 分钟/个）。</div>
          <div class="bar"><div class="fill" style="width:${n}%"></div></div>
          <div>再过 ${Math.max(0,e.thresholds.l2-d(e.todaySeconds))} 分钟将进入强制暂停。</div>
          <button>我知道了</button>
        </div>
      `,r.querySelector(`button`).addEventListener(`click`,async()=>{await p({type:`acknowledge`,level:1})?u():m(r.querySelector(`.notice`))}),t.appendChild(r)}function y(e){u(),c=e.level;let t=l(),a=e.level,o=r[a]??10,s=n[a]??0,h=a>=3,_=document.createElement(`div`);_.className=`overlay`;let v=document.createElement(`div`);v.className=`card`,_.appendChild(v),t.appendChild(_);let y=`
        <h1>${a>=4?`你已经在这里很久了`:`停一下`}</h1>
        <p class="stat">今日已消耗 ${d(e.todaySeconds)} 分钟注意力，
        相当于 ${f(e.todaySeconds)} 个深度专注块。</p>
        ${g(e.lastRecord)}
      `;function b(){v.innerHTML=`
          ${y}
          <div class="countdown">${o}</div>
          ${h?`<p>继续访问需要输入下面这句话（放行 ${s} 分钟）：</p>
                 <div class="phrase">${i}</div>
                 <input type="text" placeholder="逐字输入上面的句子" disabled />`:`<p>你原本打算做什么？写下来再决定要不要继续（放行 ${s} 分钟）：</p>
                 <textarea rows="2" placeholder="例如：查一个技术方案 / 就是想放松一下" disabled></textarea>`}
          <div class="actions">
            <button class="btn-continue" disabled>付出代价，继续访问</button>
            <button class="btn-leave">回到正事</button>
          </div>
        `;let t=v.querySelector(`.countdown`),n=v.querySelector(`input, textarea`),r=v.querySelector(`.btn-continue`),c=v.querySelector(`.btn-leave`),l=o,d=setInterval(()=>{--l,t.textContent=String(l),l<=0&&(clearInterval(d),t.textContent=`·`,n.disabled=!1,n.focus(),f())},1e3),f=()=>{let e=n.value.trim();r.disabled=l>0||(h?e!==`我选择用注意力交换娱乐`:e.length<2)};n.addEventListener(`input`,f),n.addEventListener(`paste`,e=>e.preventDefault()),r.addEventListener(`click`,async()=>{await p({type:`acknowledge`,level:a,outcome:`continued`,site:e.site,text:n.value.trim()})?u():m(v)}),c.addEventListener(`click`,()=>{clearInterval(d),x()})}function x(){v.innerHTML=`
          ${y}
          <p>好选择。写下你接下来要去做的事，然后离开：</p>
          <textarea rows="2" placeholder="我接下来要去……（例如：写完 attention-toll 的统计页）"></textarea>
          <div class="actions">
            <button class="btn-leave primary" disabled>写完了，离开</button>
          </div>
          <button class="btn-back">← 返回</button>
        `;let t=v.querySelector(`textarea`),n=v.querySelector(`.btn-leave`),r=v.querySelector(`.btn-back`);t.focus(),t.addEventListener(`input`,()=>{n.disabled=t.value.trim().length<2}),t.addEventListener(`paste`,e=>e.preventDefault()),n.addEventListener(`click`,async()=>{if(!await p({type:`acknowledge`,level:a,outcome:`left`,site:e.site,text:t.value.trim()})){m(v);return}window.location.href=`about:blank`,window.close()}),r.addEventListener(`click`,()=>b())}b()}_(),setInterval(_,a),document.addEventListener(`visibilitychange`,()=>{document.hidden||_()})}}),c={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)},l=class e extends Event{static EVENT_NAME=u(`wxt:locationchange`);constructor(t,n){super(e.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}};function u(e){return`${t?.runtime?.id}:content:${e}`}var d=typeof globalThis.navigation?.addEventListener==`function`;function f(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),d?globalThis.navigation.addEventListener(`navigate`,e=>{let n=new URL(e.destination.url);n.href!==t.href&&(window.dispatchEvent(new l(n,t)),t=n)},{signal:e.signal}):e.setInterval(()=>{let e=new URL(location.href);e.href!==t.href&&(window.dispatchEvent(new l(e,t)),t=e)},1e3))}}}var p=class e{static SCRIPT_STARTED_MESSAGE_TYPE=u(`wxt:content-script-started`);id;abortController;locationWatcher=f(this);constructor(e,t){this.contentScriptName=e,this.options=t,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return t.runtime?.id??this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener(`abort`,e),()=>this.signal.removeEventListener(`abort`,e)}block(){return new Promise(()=>{})}setInterval(e,t){let n=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(n)),n}setTimeout(e,t){let n=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(n)),n}requestAnimationFrame(e){let t=requestAnimationFrame((...t)=>{this.isValid&&e(...t)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){let n=requestIdleCallback((...t)=>{this.signal.aborted||e(...t)},t);return this.onInvalidated(()=>cancelIdleCallback(n)),n}addEventListener(e,t,n,r){t===`wxt:locationchange`&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith(`wxt:`)?u(t):t,n,{...r,signal:this.signal})}notifyInvalidated(){this.abort(`Content script context invalidated`),c.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){document.dispatchEvent(new CustomEvent(e.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),this.options?.noScriptStartedPostMessage||window.postMessage({type:e.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},`*`)}verifyScriptStartedEvent(e){let t=e.detail?.contentScriptName===this.contentScriptName,n=e.detail?.messageId===this.id;return t&&!n}listenForNewerScripts(){let t=e=>{!(e instanceof CustomEvent)||!this.verifyScriptStartedEvent(e)||this.notifyInvalidated()};document.addEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(e.SCRIPT_STARTED_MESSAGE_TYPE,t))}},m={debug:(...e)=>([...e],void 0),log:(...e)=>([...e],void 0),warn:(...e)=>([...e],void 0),error:(...e)=>([...e],void 0)};return(async()=>{try{let{main:e,...t}=s;return await e(new p(`content`,t))}catch(e){throw m.error(`The content script "content" crashed on startup!`,e),e}})()})();
content;